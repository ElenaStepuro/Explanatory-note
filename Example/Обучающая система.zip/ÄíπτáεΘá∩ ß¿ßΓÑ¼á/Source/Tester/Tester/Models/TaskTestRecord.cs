﻿namespace Tester.Models
{
    public class TaskTestRecord
    {
        public int Test;
        public int Task;
    }
}
