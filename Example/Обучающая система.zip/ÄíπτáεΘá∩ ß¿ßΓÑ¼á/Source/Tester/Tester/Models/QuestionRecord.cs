﻿namespace Tester.Models
{
    public class QuestionRecord
    {
        public int  ID;
        public string Question;
        public byte[] IamgeQuest;
        public byte[] Image;
    }
}
