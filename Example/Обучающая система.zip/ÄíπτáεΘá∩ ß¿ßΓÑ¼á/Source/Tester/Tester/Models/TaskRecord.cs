﻿namespace Tester.Models
{
    public class TaskRecord
    {
        public int ID;
        public int QuestID;
        public int AnsverID;
        public int TrueID;
    }
}
