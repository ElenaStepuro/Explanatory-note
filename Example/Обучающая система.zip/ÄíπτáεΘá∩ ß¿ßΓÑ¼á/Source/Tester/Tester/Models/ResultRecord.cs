﻿namespace Tester.Models
{
    public class ResultRecord
    {
        public int TestID;
        public int UserID;
        public int Quest;
        public int Ans;
        public int Trues;
    }
}
