﻿using System;

namespace Tester.Models
{
    public class TestRecord
    {
        public int ID;
        public string Name;
        public DateTime TimeConstraint;
    }
}
