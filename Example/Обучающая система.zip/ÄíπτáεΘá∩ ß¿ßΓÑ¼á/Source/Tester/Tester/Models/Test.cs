﻿using System;

namespace Tester.Models
{
    public class Test
    {
        public int Id { get; set; }
        public int QuestCount { get; set; }
        public string Name { get; set; }
        public DateTime TimeConstraint { get; set; }
    }

}
