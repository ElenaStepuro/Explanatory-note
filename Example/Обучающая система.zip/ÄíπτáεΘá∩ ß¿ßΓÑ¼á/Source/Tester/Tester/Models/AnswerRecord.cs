﻿namespace Tester.Models
{
   public class AnswerRecord
    {
        public int ID;
        public string Answer;
       
    }
}
