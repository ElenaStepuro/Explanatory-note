﻿using System;

namespace Tester.Models
{
    public class User
    {
        public bool Status;
        public String Fio;
        public int Id;
        public String pass;
        public String login;
    }
}
