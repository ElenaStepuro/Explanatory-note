const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    context: path.resolve(__dirname, 'src'),
    devtool: "source-map",
    entry: {
        epmcas: './index.tsx'
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, "built"),
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.jsx']
    },
    module: {
        loaders: [{
            test: /\.tsx?$/,
            loader: 'awesome-typescript-loader'
        }]
    },
    plugins: [new HtmlWebpackPlugin({
        title: 'EPM-CAS',
        template: path.resolve('index.ejs'),
    })]
}