import * as React from 'react';
import { Item, ItemProps } from './Item';

export class List extends React.Component<{}, any>{

    public state = { data: null }

    private onItemClick = (data: ItemProps) => {
        alert(JSON.stringify(data));
    }

    public componentDidMount() {
        fetch('https://www.reddit.com/.json')
            .then(response => response.json())
            .then(parsed => this.setState({ data: parsed.data }))
    }

    private renderItem(item: ItemProps) {
        return <Item
            onClick={this.onItemClick}
            author={item.author}
            title={item.title}
            id={item.id}
            key={item.id}></Item>
    }

    public render() {
        if (this.state.data) {
            return <p>{this.state.data.children.map(c => this.renderItem(c.data))}</p>
        } else {
            return <p>Loading</p>
        }
    }

}