import * as React from 'react';

export interface ItemProps {
    title: string;
    author: string;
    id: string;
    onClick: (data: ItemProps) => void;
}

export class Item extends React.Component<ItemProps, void>{
    public render() {
        return (
            <span onClick={() => this.props.onClick(this.props)}>
                <i>{this.props.author}</i> - <b>{this.props.title}</b> <br />
            </span>
        )
    }

}