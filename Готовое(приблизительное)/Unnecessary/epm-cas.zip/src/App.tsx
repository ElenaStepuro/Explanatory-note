import * as React from 'react';
import { List } from './List';

interface AppState {
    secondsElapsed: number;
}

export class App extends React.Component<{}, AppState> {
    private interval: number;
    public state = { secondsElapsed: 0 };

    private tick() {
        this.setState((prevState) => ({
            secondsElapsed: prevState.secondsElapsed + 1
        }));
    }

    private componentDidMount() {
        this.interval = setInterval(() => this.tick(), 1000);
    }

    private componentWillUnmount() {
        clearInterval(this.interval);
    }

    public render() {
        return (
            <div>
                <h1>Seconds Elapsed: {this.state.secondsElapsed}</h1>
                <div>
                    <List />
                </div>
            </div>
        );
    }
}
